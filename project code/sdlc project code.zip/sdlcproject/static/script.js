function fetchOutput(scriptName) {
    const outputText = document.getElementById('outputText');
    outputText.textContent = 'Loading...';

    fetch(`/run/${scriptName}`)
        .then(response => response.json())
        .then(data => {
            if (data.output) {
                outputText.textContent = data.output;
            } else {
                outputText.textContent = `Error: ${data.error}`;
            }
        })
        .catch(error => {
            outputText.textContent = 'Failed to fetch output: ' + error;
        });
}
