import streamlit as st

# Define the pages
def home():
    st.title("Home")
    st.write("Welcome to the Smart Software Development Lifecycle application!")

def bug_fixer():
    st.title("Bug Fixer")
    st.write("This is the Bug Fixer module.")

def code_generator():
    st.title("Code Generator")
    st.write("This is the Code Generator module.")

def code_summarizer():
    st.title("Code Summarizer")
    st.write("This is the Code Summarizer module.")

def chatbot():
    st.title("Chatbot")
    st.write("This is the Chatbot module.")

def utils():
    st.title("Utils")
    st.write("This is the Utils module.")

def main():
    st.title("Main")
    st.write("This is the Main module.")

# Create a dictionary to map URLs to functions
pages = {
    "home": home,
    "bug_fixer": bug_fixer,
    "code_generator": code_generator,
    "code_summarizer": code_summarizer,
    "chatbot": chatbot,
    "utils": utils,
    "main": main,
}

# Get the page from the URL
page = st.experimental_get_query_params().get("page", ["home"])[0]

# Call the corresponding function
if page in pages:
    pages[page]()
else:
    st.error("Page not found.")
