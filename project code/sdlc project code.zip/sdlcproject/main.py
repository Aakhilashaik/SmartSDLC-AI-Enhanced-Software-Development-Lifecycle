from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import subprocess
import threading

app = FastAPI()

# Mount static directory for CSS
app.mount("/static", StaticFiles(directory="static"), name="static")

# Load HTML templates
templates = Jinja2Templates(directory="templates")

# Start Streamlit app (once only)
def run_streamlit():
    subprocess.Popen(["streamlit", "run", "app/app.py"])
    subprocess.Popen(["streamlit", "run", "app/pages/Home.py"])



@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/launch-app")
async def launch_app():
    threading.Thread(target=run_streamlit).start()
    return RedirectResponse(url="http://localhost:8501", status_code=302)
